export const BASE_URL = `https://us-central1-labenu-apis.cloudfunctions.net/labeX/`
export const BASE_URL2 = `https://us-central1-labenu-apis.cloudfunctions.net/labeX/`
export const BASE_URL3 = `https://us-central1-labenu-apis.cloudfunctions.net/labeX/`
export const BASE_URL4 = `https://us-central1-labenu-apis.cloudfunctions.net/labeX/`