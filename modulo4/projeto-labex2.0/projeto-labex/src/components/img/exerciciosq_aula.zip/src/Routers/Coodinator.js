    export const goToTripDetail=(navigate)=>{
        navigate(`/tripdetail`)
    }
    
    export const goToLogin=(navigate)=>{
        navigate(`/`)
    }
    