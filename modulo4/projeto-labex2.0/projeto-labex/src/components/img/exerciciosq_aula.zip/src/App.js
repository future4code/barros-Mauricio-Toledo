import { Formulario2 } from "./components/Formulario2";
import Rotas from "./Routers/Rotas"


function App() {
  return (
    <div className="App">
      <Rotas/>
    </div>
  );
}

export default App;
